import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../classes/user';
import { News } from '../classes/news';
import { Event } from '../classes/event';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private _http: HttpClient, private router: Router) { }

  //login api
  public loginUserFromRemote(user: User):Observable<any> {
    return this._http.post<any>("http://localhost:8080/users/login", user);
  }
  //adduser api
  public registerUserFromRemote(user: User):Observable<any> {
    return this._http.post<any>("http://localhost:8080/users/add", user);
  }

  //addnews api
  public addNewsFromRemote(news: News):Observable<any> {
    return this._http.post<any>("http://localhost:8080/news/add", news);
  }
  //get news api
  getAllNews():Observable<any>{
    return this._http.get("http://localhost:8080/news/all");
  }
  //update news api
  updateNews(news: News):Observable<any> {
    return this._http.put("http://localhost:8080/news/update/" , news);
  }

  //delete news api
  deletNews(lstnews: News):Observable<any> {
    return this._http.delete("http://localhost:8080/news/delete/" + lstnews.id);
  }

  //get news by id
  getOneNews(id: string){
    return this._http.get("http://localhost:8080/news/findById/"+ id);
  }

  //addevent api
  public addEventFromRemote(event:Event):Observable<any> {
    return this._http.post<any>("http://localhost:8080/event/add", event);
  }

  //get event by id
  getOneEvent(id: string){
    return this._http.get("http://localhost:8080/event/findById/{id}"+ id);
  }

  //update event api
  updateEvent(event: Event):Observable<any> {
    return this._http.put("http://localhost:8080/event/update", event);
  }

  //get event api
  getAllEvent():Observable<any>{
    return this._http.get("http://localhost:8080/event/all");
  }
}
