import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { News } from 'src/app/classes/news';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-editnews',
  templateUrl: './editnews.component.html',
  styleUrls: ['./editnews.component.css']
})
export class EditnewsComponent implements OnInit {
  news = new News();
  id: any;
  data: any;

  constructor(private emp: CommonService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params.id;
    this.getNews();
  }

  updateNews(news: News) {

    this.emp.updateNews(this.news).subscribe(

      data => {
        console.log("updated");
        this.router.navigate(["commondashboard"]);
      },
      error => {
        console.log("error");

      }


    );
  }


  getNews() {
    this.emp.getOneNews(this.id).subscribe(
      res => {
        console.log(res);
        this.data = res;
        this.news = this.data;
      })
  }

}
