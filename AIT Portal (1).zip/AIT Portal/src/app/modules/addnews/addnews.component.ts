import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { News } from 'src/app/classes/news';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-addnews',
  templateUrl: './addnews.component.html',
  styleUrls: ['./addnews.component.css']
})
export class AddnewsComponent implements OnInit {
  news = new News();
  

  constructor(private emp: CommonService, private router: Router) { }

  ngOnInit(): void {
  }

  addNews(){
    this.emp.addNewsFromRemote(this.news).subscribe(
      
      data=>{
      console.log("recevied");
      this.router.navigate(["commondashboard"]);
       },
      error=>{
       console.log("error");
      
      }
    )
   
   }

   
 
   
}
