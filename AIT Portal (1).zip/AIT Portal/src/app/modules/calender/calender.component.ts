import { Component, OnInit } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/angular';
import { DatePipe } from '@angular/common';
import { formatDate } from '@angular/common';
import { CommonService } from '../../services/common.service';


@Component({
  selector: 'app-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent implements OnInit {
  allEvents: any;
  
  public dataa: any = [];
  public aa: any = {}
  calendarOptions: CalendarOptions = {};
  
  constructor(private commonService: CommonService) { }

  ngOnInit() {
      this.commonService.getAllEvent().subscribe(data => {
     this.allEvents = data;
      console.log(data,"data");

      this.allEvents.forEach((element:any) => {
        this.aa = { id: String(element.id), title: element.event, date: element.date }
        this.dataa.push(this.aa);
      
      });
      console.log(this.dataa,"dataa");

    })
    setInterval(() => {
      this.calendarOptions = {
          initialView: 'dayGridMonth',
          weekends: false,
          events: this.dataa,
         
        };
        
    }, 5000);
    
  }
  

}

