import { Component, OnInit } from '@angular/core';

import { CalendarOptions } from '@fullcalendar/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 

  constructor() { }

  ngOnInit(): void {
  }

  

  calendarOptions: CalendarOptions = {
    initialView: 'dayGridMonth',
    weekends: false ,
    events: [
      { title: 'event 1', date: '2021-05-13' },
      { title: 'event 2', date: '2021-05-14' }
    ]

  };
  toggleWeekends() {
    this.calendarOptions.weekends = !this.calendarOptions.weekends // toggle the boolean!
  }

}
