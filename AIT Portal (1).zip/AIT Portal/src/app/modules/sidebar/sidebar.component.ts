import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  xyz:any;

  constructor(private router:Router,
    private emp:CommonService) { }

    ngOnInit() {
    
      //this.xyz = localStorage.getItem('uname');
      this.xyz = localStorage.getItem('first_name');
     //console.log(xyz);
    }
  addNews(){
    this.router.navigate(["addnews"]);
  }
  addUser(){
    this.router.navigate(["adduser"]);
  }
  addEvent(){
    this.router.navigate(["addevent"]);
  }
}
