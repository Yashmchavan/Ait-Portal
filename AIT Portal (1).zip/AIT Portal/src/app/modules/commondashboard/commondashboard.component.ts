import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commondashboard',
  templateUrl: './commondashboard.component.html',
  styleUrls: ['./commondashboard.component.css']
})
export class CommondashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
