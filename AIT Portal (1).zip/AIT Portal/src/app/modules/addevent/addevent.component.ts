import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { Event } from 'src/app/classes/event';

@Component({
  selector: 'app-addevent',
  templateUrl: './addevent.component.html',
  styleUrls: ['./addevent.component.css']
})
export class AddeventComponent implements OnInit {
  event = new Event();
  constructor(private emp: CommonService, private router: Router) { }

  ngOnInit(): void {
  }
  
  addEvent(){
    this.emp.addEventFromRemote(this.event).subscribe(
      
      data=>{
      console.log("recevied");
      console.log(data.end_date);
      console.log(data.time);
      this.router.navigate(["commondashboard"]);
       },
      error=>{
       console.log("error");
      
      }
    )
   
   }

}
