import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { User } from '../../classes/user';
import { ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  roles: any = ['User', 'Admin'];
  Gender: any = ['Male', 'Female', 'Other'];
 
 
  user = new User();
  msg ='';

 
  constructor(private emp: CommonService, private router: Router,private fb: FormBuilder) { 
    this.createForm();
  }
  createForm() {
    this.registerfrm = this.fb.group({
      first_name: ['',[Validators.required ,Validators.pattern('^[a-zA-Z]+$')]],
      last_name: ['', [Validators.required ,Validators.pattern('^[a-zA-Z]+$')]],
      email: ['', [Validators.required,Validators.email]],
      password: ['', [Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{7,}')]],
      role:['', Validators.required],
      gender:['', Validators.required]
    });
  }

  ngOnInit(): void {
  }


 registerfrm = new FormGroup({
   first_name:new FormControl(),
   last_name:new FormControl(),
  email: new FormControl(),
  password: new FormControl(),
 role:new FormControl(),
 gender:new FormControl()
})

 registerUser(){
   this.emp.registerUserFromRemote(this.user).subscribe(
     
     data=>{
      if(this.registerfrm.valid){
        console.log(this.registerfrm.value);
       console.log("recevied");
       this.msg="Registration successful";
       this.router.navigate(["home"]);
      }
     },
     error=>{
      console.log("error");
      this.msg="The email address you have entered is already registered";
     }
   )
  
  }


}
