import { Component, OnInit } from '@angular/core';
import { Router ,RouterModule } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { User } from '../../classes/user';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user = new User();
  msg ='';
  constructor(public emp: CommonService, public router: Router, private fb: FormBuilder) { }
  
 // goToPage(home:string):void{
 //   this.router.navigate(["home"]);
 // }
 CheckUser() {
    this.router.navigate(["home"]);
  }
  ngOnInit() {
    //this.loginfrm = this.fb.group({
       // pwd: ['', Validators.required],
   // });
}
  loginfrm = new FormGroup({
    uname: new FormControl(),
    pwd: new FormControl(),
    first_name: new FormControl(),
    role: new FormControl()
  })
  loginUser(){
    this.emp.loginUserFromRemote(this.user).subscribe(
      
      data => {
        this.router.navigate(["commondashboard"]);
        localStorage.setItem("uname", this.loginfrm.value["uname"]);
        localStorage.setItem("pwd", this.loginfrm.value["pwd"]);
        localStorage.setItem("first_name",data.first_name);
        localStorage.setItem("role",data.role);

        console.log("received");
        console.log(data.first_name);
        console.log(data.role);
      
      },
      error => {
        console.log("error");
       this.msg ="Bad Credentials, please enter valid email id and password";
      }
      
    )
    
    }


  myimage:string ="assets/back.png";
  myimage2:string ="assets/aitlogo.png";
}
