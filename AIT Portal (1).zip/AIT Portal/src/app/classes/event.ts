export class Event {
    id: any;
    event: any;
    description: any;
    date: any;
   
    constructor(){}
}
