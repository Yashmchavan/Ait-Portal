import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FullCalendarModule } from '@fullcalendar/angular'; 
import dayGridPlugin from '@fullcalendar/daygrid'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './modules/signup/signup.component';
import { HomeComponent } from './modules/home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdduserComponent } from './modules/adduser/adduser.component';
import { HttpClientModule } from '@angular/common/http';
import { MatPasswordStrengthModule } from '@angular-material-extensions/password-strength';
import { AddeventComponent } from './modules/addevent/addevent.component';
import { HeaderComponent } from './modules/header/header.component';
import { AddnewsComponent } from './modules/addnews/addnews.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { FooterComponent } from './modules/footer/footer.component';
import { SidebarComponent } from './modules/sidebar/sidebar.component';
import { CalenderComponent } from './modules/calender/calender.component';
import { NewsComponent } from './modules/news/news.component';
import {MatSidenavModule } from '@angular/material/sidenav';
import { CommondashboardComponent } from './modules/commondashboard/commondashboard.component';
import { EditnewsComponent } from './modules/editnews/editnews.component';
import { UpdateeventComponent } from './modules/updateevent/updateevent.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

FullCalendarModule.registerPlugins([ 
  dayGridPlugin,

]);

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    HomeComponent,
    AdduserComponent,
    AddeventComponent,
    HeaderComponent,
    AddnewsComponent,
    DashboardComponent,
    FooterComponent,
    SidebarComponent,
    CalenderComponent,
    NewsComponent,
    CommondashboardComponent,
    EditnewsComponent,
    UpdateeventComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,ReactiveFormsModule,
    BrowserAnimationsModule,
    FormsModule,
    FullCalendarModule,
    HttpClientModule,
    MatPasswordStrengthModule,
    MatSidenavModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
